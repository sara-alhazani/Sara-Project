# Presentation

This presentation was written with
[reaveal.js](http://lab.hakim.se/reveal-js/), and requires no special
software to view.  Simply open `index.html` in a browser and you're good
to go.
