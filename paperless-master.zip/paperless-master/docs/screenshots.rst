.. _screenshots:

Screenshots
===========

Once everything is set-up login to paperless using the web front-end

.. image:: ./_static/Screenshot_first_run_login.png 

Nice clean interface

.. image:: ./_static/Screenshot_first_logged.png 

Some documents loaded in via ftp or using the scanners ftp. 

.. image:: ./_static/Screenshot_upload_and_scanned.png 
