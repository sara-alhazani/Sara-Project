# Thanks for using Paperless!

Working on this project has been exhausting, but rewarding at the same time.
It's just wonderful that so many people are using this thing, and in so many
crazy ways.

This file is here for everyone to post their own stories about how you use this
code.  It helps me to understand who's using it and why, and maybe to give
others an idea of how it might be used.  It's based on a Twitter exchange
between [John Glanville](https://twitter.com/hexapodium) and
[Julia Evans](https://github.com/jvns) and later better defined [here](https://github.com/paulmolluzzo/thanks-md). 

To contribute, simply issue a pull request that appends to this file something
like this:

```
### Your Name
Some friendly message
```
