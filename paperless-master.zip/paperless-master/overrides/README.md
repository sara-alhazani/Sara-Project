# Customizing Paperless

*See customization
[documentation](https://paperless.readthedocs.io/en/latest/customising.html) 
for more detail!*

The example `.css` and `.js` snippets in this folder can be placed into
one of two files in your ``PAPERLESS_MEDIADIR`` folder: `overrides.js` or 
`overrides.css`. Please feel free to submit pull requests to the main 
repository with other examples of customizations that you think others may
find useful.